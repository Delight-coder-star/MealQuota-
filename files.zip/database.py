import sqlite3
import os

class DatabaseManager:
    def __init__(self, db_name='mealquota.db'):
        self.db_name = db_name
        self.init_database()
    
    def get_connection(self):
        conn = sqlite3.connect(self.db_name)
        conn.row_factory = sqlite3.Row
        return conn
    
    def init_database(self):
        conn = self.get_connection()
        cursor = conn.cursor()
        # Employees Table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS employees (
                id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                department TEXT NOT NULL,
                daily_quota INTEGER DEFAULT 2,
                is_active BOOLEAN DEFAULT 1,
                created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        # Departments Table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS departments (
                name TEXT PRIMARY KEY,
                balance DECIMAL(10,2) DEFAULT 0.00,
                meal_price DECIMAL(10,2) DEFAULT 5.00,
                low_balance_threshold DECIMAL(10,2) DEFAULT 50.00,
                created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        # Meal Transactions Table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS meals (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                employee_id TEXT NOT NULL,
                meal_type TEXT NOT NULL CHECK(meal_type IN ('breakfast', 'lunch')),
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                department TEXT NOT NULL,
                meal_price DECIMAL(10,2) NOT NULL,
                status TEXT DEFAULT 'success',
                FOREIGN KEY (employee_id) REFERENCES employees (id),
                FOREIGN KEY (department) REFERENCES departments (name)
            )
        ''')
        # Fraud Alerts Table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS fraud_alerts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                employee_id TEXT,
                alert_type TEXT,
                description TEXT,
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                resolved BOOLEAN DEFAULT 0
            )
        ''')
        self.insert_sample_data(cursor)
        conn.commit()
        conn.close()
        print("Database initialized successfully!")
    
    def insert_sample_data(self, cursor):
        departments = [
            ('Marketing', 200.00, 5.00, 30.00),
            ('Services', 150.00, 5.00, 25.00),
            ('Mega Mart', 300.00, 5.00, 50.00),
            ('Glofex', 100.00, 5.00, 20.00),
            ('Stitches', 180.00, 5.00, 35.00)
        ]
        cursor.executemany('''
            INSERT OR IGNORE INTO departments (name, balance, meal_price, low_balance_threshold)
            VALUES (?, ?, ?, ?)
        ''', departments)
        employees = [
            ('EMP001', 'John Smith', 'Marketing', 2),
            ('EMP002', 'Sarah Johnson', 'Services', 2),
            ('EMP003', 'Mike Brown', 'Mega Mart', 2),
            ('EMP004', 'Lisa Davis', 'Glofex', 2),
            ('EMP005', 'James Wilson', 'Stitches', 2)
        ]
        cursor.executemany('''
            INSERT OR IGNORE INTO employees (id, name, department, daily_quota)
            VALUES (?, ?, ?, ?)
        ''', employees)
        print("Sample data inserted!")

db = DatabaseManager()