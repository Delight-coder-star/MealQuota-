from flask import Flask, request, jsonify, render_template, redirect, url_for
from database import db
from models import Employee, Department
from datetime import datetime, date

app = Flask(__name__)

class FraudDetector:
    def __init__(self):
        self.recent_scans = {}
    
    def check_scan(self, employee_id):
        now = datetime.now()
        if employee_id in self.recent_scans:
            last_scan = self.recent_scans[employee_id]
            time_diff = (now - last_scan).total_seconds()
            if time_diff < 120:
                self.log_fraud_alert(employee_id, "Multiple rapid scans")
                return False, "Please wait before scanning again"
        self.recent_scans[employee_id] = now
        return True, "OK"

    def log_fraud_alert(self, employee_id, reason):
        conn = db.get_connection()
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO fraud_alerts (employee_id, alert_type, description)
            VALUES (?, 'Rapid Scan', ?)
        ''', (employee_id, reason))
        conn.commit()
        conn.close()

fraud_detector = FraudDetector()

@app.route('/')
def home():
    return redirect(url_for('dashboard'))

@app.route('/api/meal-access', methods=['POST'])
def meal_access():
    try:
        data = request.get_json()
        if not data or 'card_id' not in data:
            return jsonify({'status': 'error', 'message': 'No card ID provided'})
        card_id = data['card_id']
        meal_type = data.get('meal_type', 'lunch')
        fraud_ok, fraud_message = fraud_detector.check_scan(card_id)
        if not fraud_ok:
            return jsonify({'status': 'denied', 'message': fraud_message})
        conn = db.get_connection()
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM employees WHERE id = ?', (card_id,))
        employee_data = cursor.fetchone()
        if not employee_data:
            conn.close()
            return jsonify({'status': 'denied', 'message': 'Employee not found'})
        employee = Employee(
            employee_data['id'],
            employee_data['name'],
            employee_data['department'],
            employee_data['daily_quota']
        )
        can_access, message = employee.can_access_meal(db, meal_type)
        if not can_access:
            conn.close()
            return jsonify({'status': 'denied', 'message': message})
        cursor.execute('SELECT meal_price FROM departments WHERE name = ?', (employee.department,))
        dept_data = cursor.fetchone()
        meal_price = dept_data['meal_price'] if dept_data else 5.00
        cursor.execute('''
            INSERT INTO meals (employee_id, meal_type, department, meal_price)
            VALUES (?, ?, ?, ?)
        ''', (employee.id, meal_type, employee.department, meal_price))
        cursor.execute('''
            UPDATE departments 
            SET balance = balance - ? 
            WHERE name = ?
        ''', (meal_price, employee.department))
        cursor.execute('SELECT balance FROM departments WHERE name = ?', (employee.department,))
        new_balance = cursor.fetchone()['balance']
        conn.commit()
        conn.close()
        return jsonify({
            'status': 'granted',
            'message': f'Meal access granted for {employee.name}',
            'employee_name': employee.name,
            'department': employee.department,
            'meal_type': meal_type,
            'remaining_balance': new_balance,
            'meals_today': employee.get_meals_today(db) + 1
        })
    except Exception as e:
        return jsonify({'status': 'error', 'message': f'System error: {str(e)}'})

@app.route('/dashboard')
def dashboard():
    conn = db.get_connection()
    cursor = conn.cursor()
    today = date.today().isoformat()
    cursor.execute('''
        SELECT department, COUNT(*) as meal_count 
        FROM meals 
        WHERE date(timestamp) = ?
        GROUP BY department
    ''', (today,))
    dept_meals = {row['department']: row['meal_count'] for row in cursor.fetchall()}
    cursor.execute('SELECT name, balance FROM departments')
    dept_balances = {row['name']: row['balance'] for row in cursor.fetchall()}
    cursor.execute('SELECT COUNT(*) as total FROM meals WHERE date(timestamp) = ?', (today,))
    total_meals = cursor.fetchone()['total']
    cursor.execute('''
        SELECT m.*, e.name as employee_name 
        FROM meals m 
        JOIN employees e ON m.employee_id = e.id 
        ORDER BY m.timestamp DESC 
        LIMIT 10
    ''')
    recent_meals = [dict(row) for row in cursor.fetchall()]
    conn.close()
    return render_template('dashboard.html',
                         dept_meals=dept_meals,
                         dept_balances=dept_balances,
                         total_meals=total_meals,
                         recent_meals=recent_meals)

@app.route('/employees')
def employees_list():
    conn = db.get_connection()
    cursor = conn.cursor()
    cursor.execute('''
        SELECT e.*, d.balance as dept_balance,
               (SELECT COUNT(*) FROM meals 
                WHERE employee_id = e.id AND date(timestamp) = date('now')) as meals_today
        FROM employees e
        LEFT JOIN departments d ON e.department = d.name
    ''')
    employees = [dict(row) for row in cursor.fetchall()]
    conn.close()
    return render_template('employees.html', employees=employees)

if __name__ == '__main__':
    print("Starting MealQuota Server...")
    print("Access the dashboard at: http://localhost:5000/dashboard")
    app.run(debug=True, host='0.0.0.0', port=5000)