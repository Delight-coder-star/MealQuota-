from datetime import date

class Employee:
    def __init__(self, employee_id, name, department, daily_quota=2):
        self.id = employee_id
        self.name = name
        self.department = department
        self.daily_quota = daily_quota
    
    def get_meals_today(self, db_manager):
        conn = db_manager.get_connection()
        cursor = conn.cursor()
        today = date.today().isoformat()
        cursor.execute('''
            SELECT COUNT(*) as meal_count 
            FROM meals 
            WHERE employee_id = ? AND date(timestamp) = ?
        ''', (self.id, today))
        result = cursor.fetchone()
        conn.close()
        return result['meal_count'] if result else 0
    
    def can_access_meal(self, db_manager, meal_type):
        meals_today = self.get_meals_today(db_manager)
        if meals_today >= self.daily_quota:
            return False, "Daily quota exceeded"
        conn = db_manager.get_connection()
        cursor = conn.cursor()
        cursor.execute('SELECT balance FROM departments WHERE name = ?', (self.department,))
        dept = cursor.fetchone()
        conn.close()
        if not dept or dept['balance'] <= 0:
            return False, "Department balance insufficient"
        return True, "Access granted"

class Department:
    def __init__(self, name, balance=0.0, meal_price=5.00):
        self.name = name
        self.balance = balance
        self.meal_price = meal_price
    
    def get_daily_meals(self, db_manager):
        conn = db_manager.get_connection()
        cursor = conn.cursor()
        today = date.today().isoformat()
        cursor.execute('''
            SELECT COUNT(*) as meal_count 
            FROM meals 
            WHERE department = ? AND date(timestamp) = ?
        ''', (self.name, today))
        result = cursor.fetchone()
        conn.close()
        return result['meal_count'] if result else 0
    
    def get_total_spent_today(self, db_manager):
        conn = db_manager.get_connection()
        cursor = conn.cursor()
        today = date.today().isoformat()
        cursor.execute('''
            SELECT SUM(meal_price) as total_spent
            FROM meals 
            WHERE department = ? AND date(timestamp) = ?
        ''', (self.name, today))
        result = cursor.fetchone()
        conn.close()
        return result['total_spent'] if result and result['total_spent'] else 0.0